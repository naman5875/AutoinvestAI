import React, { useState, useEffect } from 'react'
import axios from 'axios'

export default function Risk() {
  const [risk, setRisk] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchRisk = async () => {
      try {
        const res = await axios.get('/api/v1/risk/summary/')
        setRisk(res.data)
        setLoading(false)
      } catch (err) {
        setLoading(false)
      }
    }
    fetchRisk()
  }, [])

  if (loading) return <div style={msgStyle}>Loading Risk Parameters...</div>

  return (
    <div>
      <h2 style={{ margin: '0 0 24px', fontSize: '28px' }}>Risk Management Control</h2>
      
      <div style={containerStyle}>
        <div style={rowStyle}>
          <strong>Risk Evaluation Score:</strong>
          <span style={{ color: '#00e5a0', fontWeight: 'bold' }}>{risk?.risk_score} / 100</span>
        </div>
        <div style={rowStyle}>
          <strong>Assigned Profile:</strong>
          <span>{risk?.risk_level}</span>
        </div>
        <div style={rowStyle}>
          <strong>Max Drawdown Allowance:</strong>
          <span>{risk?.max_drawdown_limit}</span>
        </div>
        <div style={rowStyle}>
          <strong>Daily Loss Safety Stop:</strong>
          <span>₹{parseFloat(risk?.daily_loss_limit).toLocaleString('en-IN')}</span>
        </div>
        <div style={rowStyle}>
          <strong>Current Status:</strong>
          <span style={{ color: '#00e5a0', fontWeight: 'bold' }}>{risk?.status}</span>
        </div>
      </div>
    </div>
  )
}

const msgStyle = { display: 'flex', justifyContent: 'center', alignItems: 'center', height: '60vh', color: '#00e5a0' }
const containerStyle = { background: '#0b132b', border: '1px solid #1e293b', padding: '24px', borderRadius: '8px', maxWidth: '600px' }
const rowStyle = { display: 'flex', justifyContent: 'space-between', padding: '14px 0', borderBottom: '1px solid #1e293b' }
