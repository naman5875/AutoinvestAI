import React, { useState, useEffect } from 'react'
import axios from 'axios'

export default function Dashboard() {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  
  const [scrapeStatus, setScrapeStatus] = useState('')
  const [tradeStatus, setTradeStatus] = useState('')
  const [ticker, setTicker] = useState('RELIANCE')

  const fetchDashboardData = async () => {
    try {
      const res = await axios.get('/api/v1/trading/portfolio/')
      setData(res.data)
      setLoading(false)
    } catch (err) {
      setError('Failed to connect to Django API. Ensure your backend and Redis are running.')
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchDashboardData()
    const interval = setInterval(fetchDashboardData, 5000) // Poll every 5 seconds
    return () => clearInterval(interval)
  }, [])

  const handleScrape = async () => {
    setScrapeStatus('Scraping started...')
    try {
      const res = await axios.post('/api/v1/scrape/')
      setScrapeStatus(res.data.status || 'Scraping task successfully dispatched.')
    } catch (err) {
      setScrapeStatus('Scraping task call failed.')
    }
  }

  const handleTrade = async () => {
    setTradeStatus(`Agent running for ${ticker}...`)
    try {
      const res = await axios.post('/api/v1/trade-agent/', { symbol: ticker })
      setTradeStatus(res.data.status || 'AI evaluation task successfully dispatched.')
      fetchDashboardData()
    } catch (err) {
      setTradeStatus('AI evaluation task call failed.')
    }
  }

  if (loading) return <div style={msgStyle}>Loading AutoInvest Dashboard...</div>
  if (error) return <div style={{...msgStyle, color: '#ef4444'}}>{error}</div>

  return (
    <div>
      <h2 style={pageTitleStyle}>Performance Dashboard</h2>

      {/* Grid Cards */}
      <div style={gridStyle}>
        <div style={cardStyle}>
          <div style={cardLabelStyle}>CASH AVAILABLE</div>
          <div style={cardValueStyle}>₹{parseFloat(data.cash_available).toLocaleString('en-IN', { minimumFractionDigits: 2 })}</div>
        </div>
        <div style={cardStyle}>
          <div style={cardLabelStyle}>TOTAL PORTFOLIO VALUE</div>
          <div style={cardValueStyle}>₹{parseFloat(data.total_value).toLocaleString('en-IN', { minimumFractionDigits: 2 })}</div>
        </div>
        <div style={cardStyle}>
          <div style={cardLabelStyle}>OPEN POSITIONS</div>
          <div style={cardValueStyle}>{data.open_positions}</div>
        </div>
        <div style={cardStyle}>
          <div style={cardLabelStyle}>TRADING STATUS</div>
          <div style={{ ...cardValueStyle, color: '#00e5a0' }}>{data.trading_status}</div>
        </div>
      </div>

      {/* Action Buttons Section */}
      <div style={actionSectionStyle}>
        <div style={actionCardStyle}>
          <h3 style={sectionTitleStyle}>News Ingestion Pipeline</h3>
          <p style={sectionDescStyle}>Collect, clean, and vectorize latest Sensex market headlines from CNBC.</p>
          <button onClick={handleScrape} style={buttonStyle}>Trigger CNBC Scrape</button>
          {scrapeStatus && <div style={statusText}>{scrapeStatus}</div>}
        </div>

        <div style={actionCardStyle}>
          <h3 style={sectionTitleStyle}>Execute RAG Trading Agent</h3>
          <p style={sectionDescStyle}>Run autonomous evaluation based on local memory and live stock data.</p>
          <div style={{ display: 'flex', gap: '10px', margin: '15px 0' }}>
            <input 
              type="text" 
              value={ticker} 
              onChange={(e) => setTicker(e.target.value.toUpperCase())}
              style={inputStyle}
              placeholder="Ticker Symbol (e.g. RELIANCE)"
            />
            <button onClick={handleTrade} style={buttonStyle}>Run AI Agent</button>
          </div>
          {tradeStatus && <div style={statusText}>{tradeStatus}</div>}
        </div>
      </div>

      {/* Positions Table */}
      <div style={tableSectionStyle}>
        <h3 style={sectionTitleStyle}>Simulated Positions Holdings</h3>
        {data.positions && data.positions.length > 0 ? (
          <table style={tableStyle}>
            <thead>
              <tr>
                <th style={thStyle}>Stock Ticker</th>
                <th style={thStyle}>Quantity</th>
                <th style={thStyle}>Avg Purchase Price</th>
              </tr>
            </thead>
            <tbody>
              {data.positions.map((pos, idx) => (
                <tr key={idx} style={trStyle}>
                  <td style={tdStyle}>{pos.symbol}</td>
                  <td style={tdStyle}>{pos.quantity}</td>
                  <td style={tdStyle}>₹{parseFloat(pos.avg_price).toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p style={{ color: '#94a3b8', margin: 0 }}>No open simulated portfolio positions held.</p>
        )}
      </div>

      {/* Activity Logs */}
      <div style={tableSectionStyle}>
        <h3 style={sectionTitleStyle}>Execution & Activity Logs</h3>
        {data.trade_history && data.trade_history.length > 0 ? (
          <div style={{ maxHeight: '300px', overflowY: 'auto' }}>
            <table style={tableStyle}>
              <thead>
                <tr>
                  <th style={thStyle}>Timestamp</th>
                  <th style={thStyle}>Ticker</th>
                  <th style={thStyle}>Action</th>
                  <th style={thStyle}>Price</th>
                  <th style={thStyle}>Decision Rationale (RAG LLM Context)</th>
                </tr>
              </thead>
              <tbody>
                {data.trade_history.map((log, idx) => (
                  <tr key={idx} style={trStyle}>
                    <td style={tdStyle}>{new Date(log.timestamp).toLocaleString()}</td>
                    <td style={tdStyle}>{log.symbol}</td>
                    <td style={{ ...tdStyle, fontWeight: 'bold', color: log.action === 'BUY' ? '#00e5a0' : log.action === 'SELL' ? '#ef4444' : '#94a3b8' }}>{log.action}</td>
                    <td style={tdStyle}>₹{parseFloat(log.price).toFixed(2)}</td>
                    <td style={{ ...tdStyle, fontSize: '12px', color: '#cbd5e1', maxWidth: '400px', lineBreak: 'anywhere' }}>{log.reason}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p style={{ color: '#94a3b8', margin: 0 }}>No trade executions logged in database yet.</p>
        )}
      </div>
    </div>
  )
}

// Inline Styling Declarations
const pageTitleStyle = { margin: '0 0 24px', fontSize: '28px', color: '#f1f5f9' }
const gridStyle = { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '20px', marginBottom: '30px' }
const cardStyle = { background: '#0b132b', border: '1px solid #1e293b', padding: '20px', borderRadius: '8px' }
const cardLabelStyle = { fontSize: '12px', color: '#94a3b8', letterSpacing: '1px', marginBottom: '8px', fontWeight: '600' }
const cardValueStyle = { fontSize: '24px', fontWeight: 'bold' }
const msgStyle = { display: 'flex', justifyContent: 'center', alignItems: 'center', height: '60vh', color: '#00e5a0', fontWeight: 'bold' }
const actionSectionStyle = { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginBottom: '30px' }
const actionCardStyle = { background: '#0b132b', border: '1px solid #1e293b', padding: '20px', borderRadius: '8px' }
const buttonStyle = { background: '#00e5a0', color: '#04080f', border: 'none', padding: '10px 18px', borderRadius: '4px', fontWeight: 'bold', cursor: 'pointer', fontSize: '14px' }
const inputStyle = { background: '#04080f', border: '1px solid #1e293b', color: '#f1f5f9', padding: '8px 12px', borderRadius: '4px', fontSize: '14px', flex: 1 }
const statusText = { marginTop: '10px', fontSize: '13px', color: '#00e5a0' }
const tableSectionStyle = { background: '#0b132b', border: '1px solid #1e293b', padding: '24px', borderRadius: '8px', marginBottom: '30px' }
const tableStyle = { width: '100%', borderCollapse: 'collapse', textAlign: 'left' }
const thStyle = { padding: '12px', borderBottom: '2px solid #1e293b', color: '#94a3b8', fontSize: '13px', fontWeight: '600' }
const trStyle = { borderBottom: '1px solid #1e293b' }
const tdStyle = { padding: '12px', fontSize: '14px' }
const sectionTitleStyle = { margin: '0 0 10px', fontSize: '18px', color: '#00e5a0' }
const sectionDescStyle = { margin: '0 0 20px', fontSize: '14px', color: '#cbd5e1' }
