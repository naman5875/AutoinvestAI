import React from 'react'
import { Routes, Route, Link, useLocation } from 'react-router-dom'
import Dashboard from './pages/Dashboard'
import Risk from './pages/Risk'

export default function App() {
  const location = useLocation()

  return (
    <div style={appContainerStyle}>
      {/* Header Navigation */}
      <header style={headerStyle}>
        <div style={logoStyle}>AutoInvest AI</div>
        <nav style={navStyle}>
          <Link to="/" style={location.pathname === '/' ? activeLinkStyle : linkStyle}>Dashboard</Link>
          <Link to="/risk" style={location.pathname === '/risk' ? activeLinkStyle : linkStyle}>Risk Control</Link>
        </nav>
      </header>

      {/* Main Content */}
      <main style={mainStyle}>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/risk" element={<Risk />} />
        </Routes>
      </main>

      {/* Status Footer */}
      <footer style={footerStyle}>
        <div style={statusDotContainer}>
          <span style={statusDot}></span> Django API Status: Connected
        </div>
        <div>v1.0.0 (Simulated Paper Trading Mode)</div>
      </footer>
    </div>
  )
}

const appContainerStyle = { display: 'flex', flexDirection: 'column', minHeight: '100vh', background: '#04080f' }
const headerStyle = { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '16px 24px', background: '#0b132b', borderBottom: '1px solid #1e293b' }
const logoStyle = { fontSize: '20px', fontWeight: 'bold', color: '#00e5a0' }
const navStyle = { display: 'flex', gap: '20px' }
const linkStyle = { color: '#94a3b8', textDecoration: 'none', fontSize: '14px', fontWeight: '500' }
const activeLinkStyle = { color: '#00e5a0', textDecoration: 'none', fontSize: '14px', fontWeight: '700' }
const mainStyle = { flex: 1, padding: '24px', maxWidth: '1200px', margin: '0 auto', width: '100%' }
const footerStyle = { display: 'flex', justifyContent: 'space-between', padding: '12px 24px', background: '#0b132b', borderTop: '1px solid #1e293b', fontSize: '12px', color: '#94a3b8' }
const statusDotContainer = { display: 'flex', alignItems: 'center', gap: '6px' }
const statusDot = { width: '8px', height: '8px', background: '#00e5a0', borderRadius: '50%' }
