from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.decorators import api_view
from .models import PaperPortfolio, PaperPosition, PaperTradeLog
from .tasks import run_trading_agent, scrape_cnbc_news

class PortfolioDashboardAPI(APIView):
    def get(self, request):
        portfolio, _ = PaperPortfolio.objects.get_or_create(id=1)
        positions = PaperPosition.objects.all().values()
        logs = PaperTradeLog.objects.all().order_by('-timestamp')[:20].values()

        return Response({
            "cash_balance": portfolio.cash_balance,
            "positions": list(positions),
            "trade_history": list(logs)
        })

@api_view(['POST'])
def trigger_scrape(request):
    scrape_cnbc_news.delay()
    return Response({"status": "Scraping task dispatched successfully."})

@api_view(['POST'])
def trigger_agent(request):
    symbol = request.data.get("symbol", "RELIANCE")
    run_trading_agent.delay(symbol)
    return Response({"status": f"Agent dispatched for {symbol}."})
