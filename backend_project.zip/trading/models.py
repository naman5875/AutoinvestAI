from django.db import models

class PaperPortfolio(models.Model):
    cash_balance = models.DecimalField(max_digits=12, decimal_places=2, default=100000.00)

    def __str__(self):
        return f"Portfolio Balance: ₹{self.cash_balance}"

class PaperPosition(models.Model):
    symbol = models.CharField(max_length=20, unique=True)
    quantity = models.PositiveIntegerField(default=0)
    avg_price = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)

    def __str__(self):
        return f"{self.symbol} - {self.quantity} shares @ ₹{self.avg_price}"

class PaperTradeLog(models.Model):
    ACTIONS = [('BUY', 'Buy'), ('SELL', 'Sell'), ('HOLD', 'Hold')]
    timestamp = models.DateTimeField(auto_now_add=True)
    symbol = models.CharField(max_length=20)
    action = models.CharField(max_length=10, choices=ACTIONS)
    quantity = models.PositiveIntegerField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    reason = models.TextField()

    def __str__(self):
        return f"[{self.action}] {self.symbol} - {self.quantity} shares"
