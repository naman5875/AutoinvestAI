from django.urls import path
from .views import PortfolioDashboardAPI, trigger_scrape, trigger_agent

urlpatterns = [
    path('dashboard/', PortfolioDashboardAPI.as_view(), name='dashboard'),
    path('scrape/', trigger_scrape, name='trigger_scrape'),
    path('trade-agent/', trigger_agent, name='trigger_agent'),
]
