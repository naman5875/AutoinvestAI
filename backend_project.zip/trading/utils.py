import yfinance as yf
from .models import PaperPortfolio, PaperPosition, PaperTradeLog

def get_current_bse_price(symbol):
    try:
        ticker_symbol = symbol if symbol.endswith(".BO") else f"{symbol}.BO"
        ticker = yf.Ticker(ticker_symbol)
        price = ticker.fast_info['lastPrice']
        return float(price)
    except Exception as e:
        print(f"Error fetching live price for {symbol}: {e}")
        return 1500.00

def execute_paper_trade(symbol, action, reason):
    portfolio, _ = PaperPortfolio.objects.get_or_create(id=1)
    price = get_current_bse_price(symbol)
    
    trade_value = 15000.00
    quantity = int(trade_value // price) if price > 0 else 0

    if quantity <= 0:
        return f"Trade price ₹{price} exceeds standard cash allocation."

    if action == "BUY":
        cost = float(price) * quantity
        if float(portfolio.cash_balance) >= cost:
            portfolio.cash_balance = float(portfolio.cash_balance) - cost
            portfolio.save()

            position, created = PaperPosition.objects.get_or_create(symbol=symbol)
            if created:
                position.quantity = quantity
                position.avg_price = price
            else:
                total_qty = position.quantity + quantity
                total_cost = (float(position.avg_price) * position.quantity) + cost
                position.avg_price = total_cost / total_qty
                position.quantity = total_qty
            position.save()

            PaperTradeLog.objects.create(
                symbol=symbol, action='BUY', quantity=quantity, price=price, reason=reason
            )
            return f"SIMULATED BUY: {quantity} shares of {symbol} at ₹{price}"
        return "SIMULATED BUY FAILED: Insufficient paper funds."

    elif action == "SELL":
        try:
            position = PaperPosition.objects.get(symbol=symbol)
            if position.quantity > 0:
                sell_qty = position.quantity
                revenue = float(price) * sell_qty
                
                portfolio.cash_balance = float(portfolio.cash_balance) + revenue
                portfolio.save()
                position.delete()

                PaperTradeLog.objects.create(
                    symbol=symbol, action='SELL', quantity=sell_qty, price=price, reason=reason
                )
                return f"SIMULATED SELL: Sold {sell_qty} shares of {symbol} at ₹{price}"
        except PaperPosition.DoesNotExist:
            return f"SIMULATED SELL FAILED: No position held in {symbol}."

    elif action == "HOLD":
        PaperTradeLog.objects.create(
            symbol=symbol, action='HOLD', quantity=0, price=price, reason=reason
        )
        return f"SIMULATED HOLD: Logged HOLD decision for {symbol}."

    return "No trade action taken."
