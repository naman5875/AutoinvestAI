import json
import requests
from bs4 import BeautifulSoup
from celery import shared_task
from langchain_community.vectorstores import Chroma
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain.text_splitter import RecursiveCharacterTextSplitter

from .utils import execute_paper_trade

embeddings = OpenAIEmbeddings()
db = Chroma(persist_directory="./chroma_db", embedding_function=embeddings)

@shared_task
def scrape_cnbc_news():
    url = "https://www.cnbctv18.com/market/stocks/"
    headers = {'User-Agent': 'Mozilla/5.0'}
    
    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            soup = BeautifulSoup(response.text, 'html.parser')
            articles = soup.find_all('p') or soup.find_all('div', class_='text')
            
            texts = [art.get_text() for art in articles if len(art.get_text()) > 50]
            full_text = "
".join(texts)

            text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
            docs = text_splitter.create_documents([full_text])

            db.add_documents(docs)
            return f"Successfully added {len(docs)} documents to vector database."
    except Exception as e:
        return f"Scrape failed: {e}"
    return "Failed to fetch content."

@shared_task
def run_trading_agent(symbol):
    query = f"Latest news, analysis, and outlook for {symbol}"
    docs = db.similarity_search(query, k=3)
    context = "
".join([doc.page_content for doc in docs])

    if not context:
        return f"Insufficient context in database to analyze {symbol}."

    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    prompt = f"\n    You are an AI paper trading assistant. \n    Analyze the following market news context on {symbol} and decide to BUY, SELL, or HOLD.\n    \n    Context:\n    {context}\n    \n    Respond STRICTLY in JSON format with keys \"signal\" and \"reason\":\n    {{\"signal\": \"BUY|SELL|HOLD\", \"reason\": \"reason here\"}}\n    "

    try:
        response = llm.predict(prompt)
        decision = json.loads(response)
        
        action = decision.get("signal", "HOLD").upper()
        reason = decision.get("reason", "No reason provided.")
        
        result = execute_paper_trade(symbol, action, reason)
        return result
    except Exception as e:
        return f"Error executing trading agent run: {e}"
